from src.example_package_edyMartin.modulo import jsonc
